/**
 * 
 */
/**
 * @author beatlm
 *
 */
package com.thermomix.recipes.repository;