/**
 * 
 */
/**
 * @author beatlm
 *
 */
package com.thermomix.users.entity;