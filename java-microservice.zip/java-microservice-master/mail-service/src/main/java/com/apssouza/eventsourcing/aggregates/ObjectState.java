package com.apssouza.eventsourcing.aggregates;

/**
 * State object interface
 *
 * @author apssouza
 */
public interface ObjectState {

}
