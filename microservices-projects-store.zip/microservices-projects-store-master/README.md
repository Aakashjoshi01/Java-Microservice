# Microservices Projects Store

### 🎯 [Microservices Architecture- Theory Only](https://github.com/greenlearner01/Microservices-Architecture)

### 🎯 [Online Shopping Portal](https://github.com/greenlearner01/microservices-projects-store/tree/master/Online-Shopping-Portal)
