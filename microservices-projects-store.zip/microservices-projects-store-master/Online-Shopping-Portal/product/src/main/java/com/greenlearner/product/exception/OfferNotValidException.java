package com.greenlearner.product.exception;

/**
 * @author - GreenLearner(https://www.youtube.com/c/greenlearner)
 */
public class OfferNotValidException extends RuntimeException {
    public OfferNotValidException(String s) {
        super(s);
    }
}
