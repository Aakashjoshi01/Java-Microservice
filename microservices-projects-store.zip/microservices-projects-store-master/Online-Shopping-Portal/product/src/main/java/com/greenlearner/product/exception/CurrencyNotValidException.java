package com.greenlearner.product.exception;

/**
 * @author - GreenLearner(https://www.youtube.com/c/greenlearner)
 */
public class CurrencyNotValidException extends RuntimeException {
    public CurrencyNotValidException(String s) {
        super(s);
    }
}
