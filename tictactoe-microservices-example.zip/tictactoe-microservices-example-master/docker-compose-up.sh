#!/usr/bin/env bash
echo ./gradlew :dockerComposeUp
./gradlew :dockerComposeUp --info
