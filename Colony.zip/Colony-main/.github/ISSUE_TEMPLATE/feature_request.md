---
name: Feature request
about: Suggest an idea for this project

---

**Is your feature request related to a problem or something you would like to see? Please describe.**
A clear and concise description of what the problem or the new feature is. Ex. I'm always frustrated when [...]
